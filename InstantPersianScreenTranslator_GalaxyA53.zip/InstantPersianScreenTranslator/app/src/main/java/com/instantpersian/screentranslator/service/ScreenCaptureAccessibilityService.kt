package com.instantpersian.screentranslator.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Method A: Accessibility Service for Instant DOM Screen Text Extraction.
 */
class ScreenCaptureAccessibilityService : AccessibilityService() {

    companion object {
        var instance: ScreenCaptureAccessibilityService? = null
            private set
    }

    private data class NodeTextEntry(
        val text: String,
        val bounds: Rect,
        val isHeading: Boolean,
        val depth: Int
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    fun extractVisibleScreenText(): String {
        val rootNode = rootInActiveWindow ?: return ""
        val entries = mutableListOf<NodeTextEntry>()
        val seenTexts = HashSet<String>()

        try {
            traverseNode(rootNode, entries, seenTexts, depth = 0)
        } finally {
            try { rootNode.recycle() } catch (_: Exception) {}
        }

        if (entries.isEmpty()) return ""

        // Sort entries by visual reading order (top to bottom, left to right)
        entries.sortWith(Comparator { a, b ->
            val yDiff = a.bounds.top - b.bounds.top
            if (Math.abs(yDiff) > 35) yDiff else a.bounds.left - b.bounds.left
        })

        val sb = StringBuilder()
        var lastBottom = -1

        for (entry in entries) {
            val trimmed = entry.text.trim()
            if (trimmed.isEmpty()) continue

            if (lastBottom != -1 && (entry.bounds.top - lastBottom) > 40) {
                sb.append("\n\n")
            } else if (sb.isNotEmpty() && !sb.endsWith("\n") && !sb.endsWith(" ")) {
                sb.append(" ")
            }

            sb.append(trimmed)
            lastBottom = entry.bounds.bottom
        }

        return sb.toString().trim()
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo,
        entries: MutableList<NodeTextEntry>,
        seenTexts: HashSet<String>,
        depth: Int
    ) {
        if (node.isPassword) return
        if (node.packageName?.toString() == packageName) return
        if (!node.isVisibleToUser) return

        val textToUse = when {
            !node.text.isNullOrEmpty() -> node.text.toString().trim()
            !node.contentDescription.isNullOrEmpty() && (node.isClickable || depth < 5) -> node.contentDescription.toString().trim()
            else -> null
        }

        if (!textToUse.isNullOrEmpty() && !seenTexts.contains(textToUse)) {
            seenTexts.add(textToUse)
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            if (bounds.width() > 0 && bounds.height() > 0) {
                val isHeading = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) node.isHeading else bounds.height() > 80
                entries.add(NodeTextEntry(textToUse, bounds, isHeading, depth))
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                traverseNode(child, entries, seenTexts, depth + 1)
            } finally {
                try { child.recycle() } catch (_: Exception) {}
            }
        }
    }
}