package com.instantpersian.screentranslator.translation

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

data class TranslationResult(
    val translatedText: String,
    val detectedSourceLanguage: String = "auto",
    val isSuccess: Boolean = true,
    val errorMessage: String? = null
)

/**
 * Multi-tier real Persian translation engine with automatic language detection.
 */
object TranslationRepository {

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    private var mlKitEnglishToPersianTranslator: com.google.mlkit.nl.translate.Translator? = null
    private var isOfflineModelReady = false

    fun prewarm(context: Context) {
        try {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.PERSIAN)
                .build()
            val translator = Translation.getClient(options)
            mlKitEnglishToPersianTranslator = translator
            val conditions = DownloadConditions.Builder().requireWifi().build()
            translator.downloadModelIfNeeded(conditions).addOnSuccessListener {
                isOfflineModelReady = true
            }
        } catch (_: Exception) {}
    }

    suspend fun translateToPersian(context: Context, text: String): TranslationResult = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return@withContext TranslationResult("", isSuccess = false, errorMessage = "متن ورودی خالی است.")
        }

        if (isOnline(context)) {
            val onlineResult = translateViaOnlineEngine(trimmed)
            if (onlineResult.isSuccess) return@withContext onlineResult
        }

        if (isOfflineModelReady && mlKitEnglishToPersianTranslator != null) {
            val offlineResult = translateViaOfflineEngine(trimmed)
            if (offlineResult.isSuccess) return@withContext offlineResult
        }

        TranslationResult("", isSuccess = false, errorMessage = "عدم دسترسی به اینترنت و عدم آماده‌بودن مدل آفلاین.")
    }

    private suspend fun translateViaOnlineEngine(rawText: String): TranslationResult = withContext(Dispatchers.IO) {
        try {
            val paragraphs = rawText.split(Regex("(\\r?\\n){2,}"))
            val translatedParagraphs = mutableListOf<String>()
            var detectedLang = "auto"

            for (paragraph in paragraphs) {
                val cleanParagraph = paragraph.trim()
                if (cleanParagraph.isEmpty()) continue

                val encodedQuery = URLEncoder.encode(cleanParagraph, "UTF-8")
                val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=fa&dt=t&dt=bd&q=$encodedQuery"

                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Galaxy A53) AppleWebKit/537.36")
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val bodyString = response.body?.string() ?: throw Exception("Empty body")
                    val jsonArray = JSONArray(bodyString)
                    val sentencesArray = jsonArray.optJSONArray(0)
                    val paragraphSb = StringBuilder()
                    if (sentencesArray != null) {
                        for (i in 0 until sentencesArray.length()) {
                            val sentenceObj = sentencesArray.optJSONArray(i)
                            if (sentenceObj != null && sentenceObj.length() > 0) {
                                paragraphSb.append(sentenceObj.optString(0, ""))
                            }
                        }
                    }
                    if (jsonArray.length() > 2) {
                        val lang = jsonArray.optString(2, "")
                        if (lang.isNotEmpty() && lang != "null") detectedLang = lang
                    }
                    translatedParagraphs.add(paragraphSb.toString().trim())
                }
            }

            TranslationResult(
                translatedText = translatedParagraphs.joinToString("\n\n"),
                detectedSourceLanguage = detectedLang,
                isSuccess = true
            )
        } catch (e: Exception) {
            TranslationResult("", isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    private suspend fun translateViaOfflineEngine(text: String): TranslationResult = suspendCancellableCoroutine { continuation ->
        val translator = mlKitEnglishToPersianTranslator ?: return@suspendCancellableCoroutine
        translator.translate(text)
            .addOnSuccessListener { translated ->
                continuation.resume(TranslationResult(translated, detectedSourceLanguage = "en", isSuccess = true))
            }
            .addOnFailureListener { e ->
                continuation.resume(TranslationResult("", isSuccess = false, errorMessage = e.localizedMessage))
            }
    }

    private fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}