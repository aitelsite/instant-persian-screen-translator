package com.instantpersian.screentranslator.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.instantpersian.screentranslator.InstantPersianApp
import com.instantpersian.screentranslator.R
import com.instantpersian.screentranslator.ocr.MlKitOcrEngine
import com.instantpersian.screentranslator.overlay.FloatingOverlayManager
import com.instantpersian.screentranslator.translation.TranslationRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Method B: Foreground Service for MediaProjection Screen Capture + ML Kit OCR.
 */
class MediaProjectionCaptureService : Service() {

    companion object {
        const val ACTION_START_CAPTURE = "action_start_capture"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        fun startCapture(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, MediaProjectionCaptureService::class.java).apply {
                action = ACTION_START_CAPTURE
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_CAPTURE) {
            val notification: Notification = NotificationCompat.Builder(this, InstantPersianApp.NOTIFICATION_CHANNEL_CAPTURE)
                .setContentTitle("مترجم فوری صفحه نمایش")
                .setContentText("در حال تصویربرداری و تشخیص متن OCR…")
                .setSmallIcon(R.drawable.ic_translate_tile)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(1001, notification)
            }

            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
            if (resultCode != 0 && resultData != null) {
                processCapture(resultCode, resultData)
            } else {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    @SuppressLint("WrongConstant")
    private fun processCapture(resultCode: Int, data: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)

        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "InstantPersianCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, null
        )

        Handler(Looper.getMainLooper()).postDelayed({
            captureAndRecognize(width, height)
        }, 300)
    }

    private fun captureAndRecognize(width: Int, height: Int) {
        serviceScope.launch {
            var bitmap: Bitmap? = null
            try {
                val image = imageReader?.acquireLatestImage()
                if (image != null) {
                    val planes = image.planes
                    val buffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * width

                    bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    bitmap.copyPixelsFromBuffer(buffer)
                    image.close()
                }
            } finally {
                cleanupMediaProjection()
            }

            if (bitmap != null) {
                FloatingOverlayManager.updateStatus("در حال تشخیص متن فارسی/انگلیسی (OCR)…", isLoading = true)
                val recognizedText = MlKitOcrEngine.recognizeText(bitmap)
                bitmap.recycle()

                if (recognizedText.isNotEmpty()) {
                    val result = TranslationRepository.translateToPersian(this@MediaProjectionCaptureService, recognizedText)
                    if (result.isSuccess) {
                        FloatingOverlayManager.updateContent(
                            this@MediaProjectionCaptureService,
                            recognizedText,
                            result.translatedText,
                            result.detectedSourceLanguage,
                            method = "ocr"
                        )
                    }
                }
            }

            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun cleanupMediaProjection() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {}
    }
}