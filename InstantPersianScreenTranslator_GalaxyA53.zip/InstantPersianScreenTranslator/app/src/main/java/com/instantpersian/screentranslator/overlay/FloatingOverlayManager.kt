package com.instantpersian.screentranslator.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.instantpersian.screentranslator.R
import com.instantpersian.screentranslator.data.TranslationHistoryManager
import com.instantpersian.screentranslator.data.TranslationRecord
import com.instantpersian.screentranslator.service.ScreenCaptureAccessibilityService
import com.instantpersian.screentranslator.translation.TranslationRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Native Android Floating WindowManager Overlay for Instant Persian Translations.
 */
object FloatingOverlayManager {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private var currentOriginalText = ""
    private var currentTranslatedText = ""
    private var isOriginalVisible = false
    private var fontSizeSp = 16f

    private val scope = CoroutineScope(Dispatchers.Main + Job())

    fun isShowing(): Boolean = overlayView != null

    fun show(context: Context, initialStatus: String = "در حال آماده‌سازی…") {
        if (overlayView != null) {
            updateStatus(initialStatus, isLoading = true)
            return
        }

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val screenWidth = context.resources.displayMetrics.widthPixels
        val width = (screenWidth * 0.90f).toInt().coerceAtMost(1000)

        val p = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = 120
        }
        params = p

        val view = buildOverlayView(context, initialStatus)
        overlayView = view
        try {
            wm.addView(view, p)
        } catch (e: Exception) {
            overlayView = null
        }
    }

    fun hide() {
        overlayView?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Exception) {}
        }
        overlayView = null
    }

    fun updateContent(context: Context, originalText: String, translatedText: String, sourceLang: String = "auto", method: String = "accessibility") {
        currentOriginalText = originalText
        currentTranslatedText = translatedText

        TranslationHistoryManager.addRecord(
            TranslationRecord(
                sourceText = originalText,
                translatedText = translatedText,
                sourceLang = sourceLang,
                targetLang = "fa",
                extractionMethod = method
            )
        )

        val root = overlayView as? LinearLayout ?: return
        val progressBar = root.findViewById<ProgressBar>(R.id.overlay_progress)
        val statusText = root.findViewById<TextView>(R.id.overlay_status_text)
        val translatedTv = root.findViewById<TextView>(R.id.overlay_translated_text)
        val originalTv = root.findViewById<TextView>(R.id.overlay_original_text)
        val contentScroll = root.findViewById<ScrollView>(R.id.overlay_scroll)

        progressBar?.visibility = View.GONE
        statusText?.visibility = View.GONE
        contentScroll?.visibility = View.VISIBLE

        translatedTv?.apply {
            text = translatedText
            visibility = View.VISIBLE
            textSize = fontSizeSp
        }

        val langDisplay = if (sourceLang != "auto") " ($sourceLang)" else ""
        originalTv?.apply {
            text = "متن اصلی$langDisplay:\n$originalText"
            visibility = if (isOriginalVisible) View.VISIBLE else View.GONE
        }
    }

    fun updateStatus(status: String, isLoading: Boolean) {
        val root = overlayView as? LinearLayout ?: return
        val progressBar = root.findViewById<ProgressBar>(R.id.overlay_progress)
        val statusText = root.findViewById<TextView>(R.id.overlay_status_text)
        val contentScroll = root.findViewById<ScrollView>(R.id.overlay_scroll)

        progressBar?.visibility = if (isLoading) View.VISIBLE else View.GONE
        if (isLoading) contentScroll?.visibility = View.GONE
        statusText?.apply {
            text = status
            visibility = View.VISIBLE
        }
    }

    private fun buildOverlayView(context: Context, initialStatus: String): View {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#EE0F172A"))
            setPadding(dp(16), dp(12), dp(16), dp(16))
            clipToOutline = true
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
        }

        val titleTv = TextView(context).apply {
            text = "مترجم فوری صفحه (فارسی)"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val btnClose = TextView(context).apply {
            text = "✕"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { hide() }
        }

        header.addView(titleTv)
        header.addView(btnClose)
        root.addView(header)

        val progressBar = ProgressBar(context).apply {
            id = R.id.overlay_progress
            visibility = View.VISIBLE
        }
        val statusTv = TextView(context).apply {
            id = R.id.overlay_status_text
            text = initialStatus
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(progressBar)
        root.addView(statusTv)

        val scroll = ScrollView(context).apply {
            id = R.id.overlay_scroll
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220))
        }

        val contentContainer = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val translatedTv = TextView(context).apply {
            id = R.id.overlay_translated_text
            setTextColor(Color.WHITE)
            textSize = fontSizeSp
            setLineSpacing(dp(4).toFloat(), 1.2f)
            textDirection = View.TEXT_DIRECTION_RTL
        }
        val originalTv = TextView(context).apply {
            id = R.id.overlay_original_text
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 12f
            visibility = View.GONE
            setPadding(0, dp(8), 0, 0)
        }

        contentContainer.addView(translatedTv)
        contentContainer.addView(originalTv)
        scroll.addView(contentContainer)
        root.addView(scroll)

        val actions = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }

        val btnCopy = Button(context).apply {
            text = "کپی ترجمه"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0F766E"))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(6) }
            setOnClickListener {
                if (currentTranslatedText.isNotEmpty()) {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Persian Translation", currentTranslatedText))
                    Toast.makeText(context, "ترجمه فارسی کپی شد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val btnOriginal = Button(context).apply {
            text = "متن اصلی"
            textSize = 12f
            setTextColor(Color.parseColor("#E2E8F0"))
            setBackgroundColor(Color.parseColor("#334155"))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(6) }
            setOnClickListener {
                isOriginalVisible = !isOriginalVisible
                originalTv.visibility = if (isOriginalVisible) View.VISIBLE else View.GONE
                text = if (isOriginalVisible) "مخفی‌سازی اصلی" else "متن اصلی"
            }
        }

        val btnRetry = Button(context).apply {
            text = "ترجمه مجدد"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0284C7"))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
            setOnClickListener {
                retranslateScreen(context)
            }
        }

        actions.addView(btnCopy)
        actions.addView(btnOriginal)
        actions.addView(btnRetry)
        root.addView(actions)

        setupDragListener(header)
        return root
    }

    private fun setupDragListener(dragHandle: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        dragHandle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = p.x
                    initialY = p.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = initialX + (event.rawX - initialTouchX).toInt()
                    p.y = initialY + (event.rawY - initialTouchY).toInt()
                    overlayView?.let { windowManager?.updateViewLayout(it, p) }
                    true
                }
                else -> false
            }
        }
    }

    private fun retranslateScreen(context: Context) {
        updateStatus("در حال استخراج مجدد صفحه…", isLoading = true)
        scope.launch {
            val accessibilityService = ScreenCaptureAccessibilityService.instance
            val text = accessibilityService?.extractVisibleScreenText() ?: ""

            if (text.isNotEmpty()) {
                val result = TranslationRepository.translateToPersian(context, text)
                if (result.isSuccess) {
                    updateContent(context, text, result.translatedText, result.detectedSourceLanguage)
                } else {
                    updateStatus(result.errorMessage ?: "خطا در ترجمه", isLoading = false)
                }
            } else {
                updateStatus("متنی در صفحه یافت نشد", isLoading = false)
            }
        }
    }
}