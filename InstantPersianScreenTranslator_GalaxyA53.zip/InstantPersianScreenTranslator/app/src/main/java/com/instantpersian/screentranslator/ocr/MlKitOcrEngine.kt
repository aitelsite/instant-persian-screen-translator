package com.instantpersian.screentranslator.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Real on-device OCR engine utilizing Google Play Services ML Kit Text Recognition.
 */
object MlKitOcrEngine {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognizeText(bitmap: Bitmap): String = suspendCancellableCoroutine { continuation ->
        try {
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val extracted = processVisionText(visionText)
                    continuation.resume(extracted)
                }
                .addOnFailureListener {
                    continuation.resume("")
                }
        } catch (e: Exception) {
            continuation.resume("")
        }
    }

    private fun processVisionText(visionText: Text): String {
        val blocks = visionText.textBlocks
        if (blocks.isEmpty()) return ""

        val sortedBlocks = blocks.sortedWith(Comparator { a, b ->
            val aBox = a.boundingBox
            val bBox = b.boundingBox
            if (aBox == null || bBox == null) return@Comparator 0
            val yDiff = aBox.top - bBox.top
            if (Math.abs(yDiff) > 40) yDiff else aBox.left - bBox.left
        })

        val sb = StringBuilder()
        for (block in sortedBlocks) {
            val blockText = block.text.trim()
            if (blockText.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append("\n\n")
                sb.append(blockText)
            }
        }

        return sb.toString().trim()
    }
}