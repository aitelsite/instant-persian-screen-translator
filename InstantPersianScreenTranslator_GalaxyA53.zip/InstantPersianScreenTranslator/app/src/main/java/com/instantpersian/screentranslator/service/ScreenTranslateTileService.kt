package com.instantpersian.screentranslator.service

import android.content.Context
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import com.instantpersian.screentranslator.R
import com.instantpersian.screentranslator.overlay.FloatingOverlayManager
import com.instantpersian.screentranslator.translation.TranslationRepository
import com.instantpersian.screentranslator.util.PermissionHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Genuine Android Quick Settings Tile for 1-Tap Screen Translation.
 */
class ScreenTranslateTileService : TileService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val hasOverlay = PermissionHelper.canDrawOverlays(this)
        val hasAccessibility = PermissionHelper.isAccessibilityServiceEnabled(this)

        if (hasOverlay && hasAccessibility) {
            tile.state = Tile.STATE_ACTIVE
            tile.label = "ترجمه صفحه"
            tile.subtitle = "آماده ترجمه به فارسی"
        } else {
            tile.state = Tile.STATE_INACTIVE
            tile.label = "ترجمه صفحه"
            tile.subtitle = "نیاز به دسترسی"
        }
        tile.icon = Icon.createWithResource(this, R.drawable.ic_translate_tile)
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        vibrateFeedback()

        // 1. Verify Overlay Permission
        if (!PermissionHelper.canDrawOverlays(this)) {
            Toast.makeText(this, "لطفاً دسترسی «نمایش روی سایر برنامه‌ها» را فعال کنید", Toast.LENGTH_LONG).show()
            startActivityAndCollapse(PermissionHelper.getOverlayPermissionIntent(this))
            return
        }

        // 2. Verify Accessibility Service
        if (!PermissionHelper.isAccessibilityServiceEnabled(this)) {
            Toast.makeText(this, "لطفاً سرویس دسترسی‌پذیری Instant Persian را روشن کنید", Toast.LENGTH_LONG).show()
            startActivityAndCollapse(PermissionHelper.getAccessibilitySettingsIntent())
            return
        }

        // 3. Initiate Immediate Translation
        collapseStatusBar()
        FloatingOverlayManager.show(this, "در حال استخراج متن از صفحه…")

        mainHandler.postDelayed({
            executeScreenTranslation()
        }, 150)
    }

    private fun executeScreenTranslation() {
        serviceScope.launch {
            val accessibilityService = ScreenCaptureAccessibilityService.instance
            val screenText = accessibilityService?.extractVisibleScreenText() ?: ""

            if (screenText.isNotEmpty()) {
                FloatingOverlayManager.updateStatus("در حال ترجمه به فارسی…", isLoading = true)
                val result = TranslationRepository.translateToPersian(this@ScreenTranslateTileService, screenText)

                if (result.isSuccess) {
                    FloatingOverlayManager.updateContent(
                        context = this@ScreenTranslateTileService,
                        originalText = screenText,
                        translatedText = result.translatedText,
                        sourceLang = result.detectedSourceLanguage,
                        method = "accessibility"
                    )
                } else {
                    FloatingOverlayManager.updateStatus(result.errorMessage ?: "خطا در ترجمه به فارسی", isLoading = false)
                }
            } else {
                FloatingOverlayManager.updateStatus(
                    "متن مستقیمی یافت نشد. می‌توانید با ضبط صفحه (OCR) متن‌های درون تصویر را اسکن نمایید.",
                    isLoading = false
                )
            }
        }
    }

    private fun vibrateFeedback() {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {}
    }

    private fun collapseStatusBar() {
        try {
            val statusBarService = getSystemService("statusbar")
            val statusBarManager = Class.forName("android.app.StatusBarManager")
            val collapse = statusBarManager.getMethod("collapsePanels")
            collapse.invoke(statusBarService)
        } catch (_: Exception) {}
    }
}