# Instant Persian Screen Translator (مترجم فوری صفحه نمایش به فارسی)
Native Android project for Samsung Galaxy A53.
Open this root directory in Android Studio (Hedgehog or newer) and click Run.